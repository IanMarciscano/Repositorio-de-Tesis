# AgroArm-1 · Decodificación jerárquica de la intención motora

Código de la tesis de maestría *Decodificación jerárquica de la intención motora
mediante electromiografía de superficie y clasificación CNN-LSTM multimodal para
una arquitectura de asistencia según necesidad en un exoesqueleto semiactivo de
miembro superior*.

Ing. Ian N. Marciscano V. · Maestría en Ciencias de la Ingeniería Mecánica,
especialidad Automatización y Robótica · Universidad Tecnológica de Panamá,
Centro Regional Universitario de Azuero · 2026.
Asesora: Dra. Ilka Banfield. Coasesor: Dr. Humberto Rodríguez.

Repositorio privado, destinado a la verificación del trabajo por la universidad.

## Qué contiene

| Carpeta | Contenido |
|---|---|
| `firmware/` | Los dos microcontroladores: adquisición mioeléctrica y control del exoesqueleto |
| `procesamiento/` | Filtrado causal, características por ventana, secuencias y partición |
| `modelos/puerta_intencion/` | Etapa 1: puerta de intención alimentada solo con sEMG |
| `modelos/clasificador_gesto/` | Etapa 2: CNN-LSTM multimodal, ablación y variantes de generalización |
| `control/` | Cadena supervisora en lazo abierto: estados, trayectoria y ley AAN |
| `analisis/` | Latencia, anticipación, falsos positivos, pasarela y comprobaciones de robustez |
| `resultados/` | Resúmenes en JSON. Los `.npz` y los `.keras` no se versionan |
| `datos/` | Vacía. Ver `datos/LEEME.md` |
| `docs/` | Trazabilidad con la tesis y la justificación metodológica original |

## Orden de ejecución

    procesamiento/01_extraer_features.py       emg_*.csv      -> featok_*.csv
    procesamiento/02_construir_secuencias.py   featok_*.csv   -> pliegue_*.npz
    modelos/clasificador_gesto/03_entrenar.py  pliegue_*.npz  -> modelo_*.keras
    modelos/puerta_intencion/05_puerta_intencion.py
    control/06_cadena_supervisora.py
    analisis/*                                  en cualquier orden

Los scripts de `analisis/` leen los `.npz` y `.keras` que producen los pasos
anteriores, más los `emg_*.csv` originales.

## Entorno

Python 3.12. `pip install -r requirements.txt`.

El entrenamiento completo son nueve modelos por configuración de vector. En un
portátil sin GPU cada uno tarda entre quince y cuarenta minutos.

## Dos configuraciones del vector de entrada

La tesis reporta dos: ψ ∈ ℝ¹⁵ con cuatro descriptores de amplitud por canal, que
es el modelo principal con 31.142 parámetros, y ψ ∈ ℝ²¹ con tres descriptores
espectrales añadidos, 31.718 parámetros, que resultó peor y se reporta como
variante en la figura 4.9.

**El código de este repositorio es el de ψ ∈ ℝ²¹.** La versión que produjo el
resultado principal se sobrescribió al reejecutar el pipeline con las
características espectrales. Las dos configuraciones se seleccionan con el
interruptor documentado en `procesamiento/README.md`.

## Limitaciones declaradas

- Un único participante, integrante del propio equipo. Sesenta y un episodios
  independientes para la puerta de intención.
- Sin actuación física sobre el usuario: toda la verificación de la capa de
  control es en lazo abierto.
- El script que produjo la tabla 4.20 de la tesis no se conservó. El apartado
  4.10 documenta la reconstrucción.
- El paso `04_evaluar.py` que anuncian los LEEME originales nunca se escribió;
  esa evaluación la hacen los scripts de `analisis/`.

## Licencia y autoría

El firmware de control del exoesqueleto, `firmware/exoesqueleto_teensy/`,
pertenece a un trabajo de tesis distinto y se incluye como contexto de la
plataforma. El resto del código es del autor.
